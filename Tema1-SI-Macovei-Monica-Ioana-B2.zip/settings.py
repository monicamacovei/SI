Q = 5
K3 = "bFAZAYQqZbQaU7tX"
